using System;
using System.Collections;
using TMPro;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    [SerializeField] private GameObject start;
    [SerializeField] private GameObject AttemptsCar; //남은 횟수 세기
    [SerializeField] private GameObject GameOver; //게임오버

    [SerializeField] private Animator title; //타이틀 애니메이션

    [SerializeField] private Transform AttemptsStore; //횟수 복제 한꺼번에 지우기 위한 부모

    [SerializeField] private TMP_Text startnotice; //조작법 안내
    [SerializeField] private TMP_Text speed; //속도 값
    [SerializeField] private TMP_Text Dist; //Dist 값
    [SerializeField] private TMP_Text DISTANCE; //Dist 위 글자
    [SerializeField] private TMP_Text SPEED; //speed위 글자
    [SerializeField] private TMP_Text DistGUI; //게임 오버 거리 표시

    public static bool GameStart = false; //게임 시작
    private bool AlReadyGameOverFunction = false; //게임 오버 확인
    private bool AlReadyAnime = false; //애니메이션 재생 확인
    private int steps = 30; //투명도 조절 숫자 클 수록 부드러워짐!!


    public static event Action Startgame;
    public static UIManager instance; //다른 스크립트에게 UIMangager 값 전달

    void Awake()
    {
        instance = this;
    }

    void Update()
    {
        if (GameManager.attempts <= 0 && HandMove.going == false && !AlReadyGameOverFunction)
        {
            StartCoroutine(GameOverFunction());
            StartCoroutine(GameOverTextAnime());
        }

        if (GameStart)
        {
            speed.gameObject.SetActive(true);
            Dist.gameObject.SetActive(true);
            DISTANCE.gameObject.SetActive(true);
            SPEED.gameObject.SetActive(true);
            speed.text = $"{GameManager.speed * 10:F0}"; //F(숫자)는 소수점 자리 표시 값
            if (GameManager.Dist > 0)
            {
                Dist.text = $"{GameManager.Dist:F0}";
            }
        }
    }
    public IEnumerator WaitAndStartGame() //IEnumerator은 yield return new WaitForSeconds(1.0f)를 쓰기 위해 필수인 함수
    {
        Startgame?.Invoke();
        Destroy(start.gameObject);
        title.Play("title");
        yield return new WaitForSeconds(1.0f);
        StartCoroutine(Startnotice());
        GameStart = true;
        Destroy(title.gameObject);
    }
    public void OnStartClicked()
    {
        StartCoroutine(WaitAndStartGame());
    }
    public void UpdateAttmeptsUI() //횟수 ui 업데이트
    {
        foreach (Transform carclone in AttemptsStore)
        {
            Destroy(carclone.gameObject);
        }
        for (float i = 0; i < GameManager.attempts; i++)
        {
            GameObject carclone = Instantiate(AttemptsCar, AttemptsStore);
            carclone.transform.localPosition = new Vector3(-2.5f + i * 100f, -4.6f, -3f);
            carclone.transform.localScale = new Vector3(1f, 1f, 0.5f);
        }
    }

    private IEnumerator Startnotice()
    {
        startnotice.gameObject.SetActive(true);
        while (true)
        {
            for (int i = 0; i <= steps; i++)
            {
                Color color = startnotice.color;
                color.a = (float)i / steps;
                startnotice.color = color;
                yield return null;
            }
            yield return new WaitForSeconds(0.3f);
            for (int i = steps; i >= 0; i--)
            {
                Color color = startnotice.color;
                color.a = (float)i / steps; //a는 alpha (투명도)
                startnotice.color = color;
                yield return null; //1프레임 쉬어주면 더 부드러워짐
            }
            yield return new WaitForSeconds(0.05f);

            if (HandMove.HandGrip)
            {
                startnotice.gameObject.SetActive(false);
                break;
            }
        }
    }

    IEnumerator GameOverFunction()
    {
        if (!AlReadyGameOverFunction)
        {
            GameManager.RestartAlReady = true;
            AlReadyGameOverFunction = true;
            GameOver.SetActive(true);
            GameManager.Instance.BGM.Stop();
            GameManager.Instance.GameOver_mp3.Play();
            DistGUI.text = $"{GameManager.Dist:F0}cm";
            while (true)
            {
                DistGUI.color = Color.red;
                yield return new WaitForSeconds(1f);
                DistGUI.color = Color.white;
                yield return new WaitForSeconds(1f);
            }
        }
    }
    IEnumerator GameOverTextAnime()
    {
        if (!AlReadyAnime)
        {
            AlReadyAnime = true;
            while (true)
            {
                for (int i = 0; i < 10; i++)
                {
                    Vector3 TempSize = DistGUI.transform.localScale;
                    TempSize.x += 0.05f;
                    DistGUI.transform.localScale = TempSize;
                    yield return new WaitForSeconds(0.05f);
                }
                for (int i = 0; i < 10; i++)
                {
                    Vector3 TempSize = DistGUI.transform.localScale;
                    TempSize.x -= 0.05f;
                    DistGUI.transform.localScale = TempSize;
                    yield return new WaitForSeconds(0.05f);
                }
            }
        }
    }
}
