using UnityEngine;

public class Obstacle : MonoBehaviour
{
    [SerializeField] private Transform maincamera;
    [SerializeField] private Sprite[] obstacle;
    [SerializeField] private GameObject IngameObject;
    [SerializeField] private GameObject Car;

    [SerializeField] private float obstacleRate = 0.5f; // 장애물 빈도 설정

    private float timer = 0f;

    float randomX = 0f;
    float randomY = 0f;
    float randomRotate = 0f;
    int LR = 0;

    void Update()
    {
        timer += Time.deltaTime; //3초마다 실행되게 하기

        if (timer >= obstacleRate)
        {
            if (!CarController.ObstacleCar)
            {
                timer = 0f;
                if (HandMove.going)
                {
                    int randomIndex = Random.Range(0, obstacle.Length);
                    Collider2D hit = Physics2D.OverlapCircle(new Vector2(randomX, randomY), 1f); //마지막 숫자는 반지름
                    int count = 0; // 시도 횟수

                    do //겹쳤는지 10번 확인 그냥 while은 x와 y가 0일때 전부 통과시키고 소환시켜버리니 do while로
                    {
                        LR = Random.Range(1, 3); //왼쪽 오른쪽 선택 1이 왼쪽
                        count++;
                        float CarRotate = Car.transform.eulerAngles.z;
                        float AboutRotate = Mathf.DeltaAngle(0f, CarRotate) / 5; //자동차의 회전 각도만큼 계산
                        if (LR == 1)
                        {
                            randomX = Random.Range(Car.transform.position.x - 2f, Car.transform.position.x) - AboutRotate+2f;
                            Debug.Log($"lx는 {randomX}");
                            randomY = Random.Range(Car.transform.position.y + 8f, Car.transform.position.y + 12f);
                            randomRotate = Random.Range(20f, 40f);                            
                        }
                        else
                        {
                            randomX = Random.Range(Car.transform.position.x, Car.transform.position.x + 2f) + AboutRotate-2f;
                            Debug.Log($"rx는 {randomX}");
                            randomY = Random.Range(Car.transform.position.y + 8f, Car.transform.position.y + 12f);
                            randomRotate = Random.Range(-20f, -40f);
                        }
                        hit = Physics2D.OverlapCircle(new Vector2(randomX, randomY), 1.5f);
                        if (hit == null)
                        {
                            break;
                        }
                    }
                    while (hit && count < 10);

                    if (hit == null)
                    {
                        GameObject spawned = Instantiate(IngameObject, new Vector3(randomX, randomY, 0f), Quaternion.Euler(0f, 0f, randomRotate));
                        if (LR == 1)
                        {
                            spawned.tag = "LeftObstacle";
                        }
                        else
                        {
                            spawned.tag = "RightObstacle";
                        }
                        spawned.GetComponent<SpriteRenderer>().sprite = obstacle[randomIndex];
                        SpriteRenderer sr = spawned.GetComponent<SpriteRenderer>();
                        Vector2 boxCol = sr.sprite.rect.size / sr.sprite.pixelsPerUnit;
                        spawned.GetComponent<CapsuleCollider2D>().size = boxCol;
                        spawned.transform.localScale = new Vector2(1.5f, 1.5f);
                        Physics2D.SyncTransforms(); //0.2초안에 유니티가 확인을 못해 추가해야함
                    }
                }
            }
        }
    }
}