using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    [SerializeField] private GameObject Hand;
    [SerializeField] private GameObject secondfloor;
    [SerializeField] private GameObject Car; //차
    [SerializeField] private GameObject StartHand; //타이틀 시작 손
    private float timer; //다용도 타이머
    public static float speed = 0f; //속도 값
    public static float attempts = 5f; //남은 횟수값
    public static float Dist = 0f; //달린 총 거리 값
    public Slider slider;
    [SerializeField] private bool alreadyspeed = false;
    public static bool BGMonoff = false; //BGM 한번만 플레이

    public static bool playcar = false;
    public static bool enginecar = false;
    public static bool RestartAlReady = false;

    public AudioSource Intro_mp3;
    public AudioSource BGM;
    public AudioSource start_mp3;
    public AudioSource Bump_mp3;
    public AudioSource Back_mp3;
    public AudioSource StartCar_mp3;
    public AudioSource EngineCar_mp3;
    public AudioSource EndCar_mp3;
    public AudioSource GameOver_mp3;

    void Awake()
    {
        Instance = this;
    }
    void Start()
    {

        Intro_mp3.Play();
        CarController.bump += PlayBump; //+=는 실행할 함수 정하기!!
        UIManager.Startgame += PlayStart;
        StartCoroutine(starthand()); //코루틴 실행할때는 무조건 스타트코루틴(함수이름())으로 하기!!!
    }

    void Update()
    {
        if (HandMove.StartInGame)
            if (!BGMonoff)
            {
                {
                    UIManager.instance.UpdateAttmeptsUI();
                    StopCoroutine(starthand());
                    StartHand.SetActive(false);
                    BGM.Play();
                    BGMonoff = true;
                }
            }

        if (HandMove.going)
        {
            if (!alreadyspeed) //고잉이 켜질때 한번만 실행
            {
                attempts -= 1;
                StartCar_mp3.Play();
                UIManager.instance.UpdateAttmeptsUI();
                speed = slider.value * 10;
                Hand.transform.eulerAngles = new Vector3(0f, 0f, 0f);
                alreadyspeed = true;
            }

            timer += Time.deltaTime;
            if (timer >= 3) //3초 지나면 실행
            {
                if (speed >= 0)
                {
                    speed -= 3f * Time.deltaTime;
                }
                else
                {
                    HandMove.going = false;
                    alreadyspeed = false;
                    timer = 0;
                }
            }
        }

        if (timer >= 0.6)
        {
            if (speed >= 3)
            {
                if (!EngineCar_mp3.isPlaying)
                {
                    EngineCar_mp3.Play();
                }
            }
            else
            {
                EngineCar_mp3.Stop();
                if (!EndCar_mp3.isPlaying)
                { EndCar_mp3.Play(); }
            }
        }

        Dist = Car.transform.position.y; //거리값 위치에 따라 조정

        if (HandMove.going == true)
        {
            //회전한 방향으로 차 이동
            Car.transform.Translate(0f, speed * Time.deltaTime, 0f);
            //속도에 따라 화면 축소/확대
            Camera.main.orthographicSize = Mathf.Lerp(Camera.main.orthographicSize, 5f + speed / 10, Time.deltaTime * 5f);
        }
    }

    void PlayStart()
    {
        Intro_mp3.Stop();
        start_mp3.Play();
    }
    void PlayBump()
    {
        Bump_mp3.Play();
    }

    public void backsound()
    {
        if (Hand.transform.position.y >= -4f)
        {
            if (!Back_mp3.isPlaying)
            {
                Back_mp3.Play();
            }
        }
    }

    private IEnumerator starthand()
    {
        while (true)
        {
            while (Mathf.DeltaAngle(0, StartHand.transform.eulerAngles.z) < 20f)
            {
                StartHand.transform.Rotate(0f, 0f, 1f);
                yield return new WaitForSeconds(0.005f);
                yield return null;
            }
            while (Mathf.DeltaAngle(0, StartHand.transform.eulerAngles.z) > -20f)
            {
                StartHand.transform.Rotate(0f, 0f, -1f);
                yield return new WaitForSeconds(0.005f);
                yield return null;
            }
        }
    }

    public void ReStart() //재시작
    {
        attempts = 5f;
        Dist = 0f;
        BGMonoff = false;
        playcar = false;
        enginecar = false;
        UIManager.GameStart = false;
        HandMove.StartInGame = false;

        CarController.bump -= PlayBump;
        UIManager.Startgame -= PlayStart;

        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}