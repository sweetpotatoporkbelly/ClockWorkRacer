using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class HandMove : MonoBehaviour
{
    public GameManager gameManager;

    public Sprite NotGrip;
    public Sprite Grip;
    public Sprite gripHand;

    public SpriteRenderer Hand;

    public GameObject Car;

    public Slider slider;

    public static bool StartInGame = false; //게임 시작
    public static bool HandGrip = false;
    public static bool going = false; //자동차 출발

    private bool mouseAnchor = false; //차를 잡았을 때 한번만 실행하는 조건문 전용
    private bool handposition = false; //출발점이 좀 앞으로 가게 되는 버그 고치기 전용 ( handPos 함수에서 사용 )
    private bool StopHand = false;

    public Vector3 worldPos;

    public static float CarRotate;

    float saveworldPosy = -2f;

    [SerializeField] private Transform MainCamera;

    Vector3 SaveViewPos;
    void Update()
    {
        //모니터 화면 픽셀 좌표 (마우스)를 게임 좌표 (오브젝트)로 바꿔줌
        Vector3 mousePos = Mouse.current.position.ReadValue(); //모니터 픽셀에서 마우스가 어딨는지 확인
        Vector3 screenPos = new Vector3(mousePos.x, mousePos.y, Mathf.Abs(Camera.main.transform.position.z));
        //마우스는 Z -10에 있기에 컴퓨터는 Z 0에 있는 오브젝트를 구별하지 못해 클릭을 할 수 없으니 여기서 거리를 직접 알려줌
        worldPos.z = 0f;

        //그리고 그 값을 겜 화면에 맞게 바꿈

        if (going)
        {
            Hand.transform.eulerAngles = Vector3.zero;
            worldPos.x = 0f;
            mouseAnchor = false;
            Hand.gameObject.SetActive(false);
            Car.gameObject.SetActive(true);

            if (!handposition)
            {
                handpos();
            }
        }
        else
        {
            if (GameManager.attempts > 0)
            {
                if (UIManager.GameStart)
                {
                    Car.gameObject.SetActive(true);
                    Hand.gameObject.SetActive(true);
                    if (!StartInGame)
                    {
                        handposition = false;
                        StartInGame = true;
                    }

                    worldPos = Camera.main.ScreenToWorldPoint(screenPos); //WorldPos를 화면의 마우스 커서 좌표 값으로 변환

                    if (Mouse.current.leftButton.isPressed)
                    {
                        if (StartInGame)
                        {
                            if (!mouseAnchor) //잡았을 때 한번만 실행
                            {
                                Collider2D hit = Physics2D.OverlapPoint(worldPos); //worldPos와 collider2d가 겹쳤는지 확인하기
                                if (hit != null && hit.gameObject == Car) //null값은 불러올 대상이 없으면 에러가 뜨니까 확인하기
                                {
                                    Hand.transform.eulerAngles = new Vector3(0, 0, 0);
                                    worldPos.x = 0f;
                                    handposition = false;
                                    saveworldPosy = worldPos.y;
                                    mouseAnchor = true;
                                    Hand.sprite = gripHand;
                                    HandGrip = true;
                                    slider.value = 0f;
                                }
                            }
                        }
                    }
                    else
                    {
                        Hand.sprite = NotGrip;
                        mouseAnchor = false;
                    }

                    float cameraY = Camera.main.transform.position.y;
                    float maxY = cameraY - 2.5f;
                    float minY = cameraY - 4f;

                    worldPos.y = Mathf.Clamp(worldPos.y, minY, maxY); //손 이동 제한

                    //메인 이동
                    if (HandGrip)
                    {
                        if (saveworldPosy > worldPos.y && worldPos.y > -4)
                        {
                            StopHand = false;
                            gameManager.backsound();
                        }
                        else
                        {
                            StopHand = true;
                        }

                        if (saveworldPosy > worldPos.y) //뒤로만 당겨지고 앞으론 안 가게
                        {
                            saveworldPosy = worldPos.y;
                        }
                    }
                    else
                    {
                        StopHand = false;
                    }

                    if (Mouse.current.leftButton.wasReleasedThisFrame) //버튼에 손을 뗐는가 확인하기
                    {
                        if (HandGrip)
                        {
                            HandGrip = false;
                            Car.transform.eulerAngles = new Vector3(0f, 0f, Hand.transform.eulerAngles.z);
                            going = true;
                            StartInGame = false;
                        }
                    }

                    if (HandGrip)
                    {
                        Car.SetActive(false);
                        //마우스 이동 제한
                        Vector3 viewPos = Camera.main.ScreenToViewportPoint(Mouse.current.position.ReadValue());
                        Vector3 targetScreen = Camera.main.WorldToScreenPoint(Vector3.zero);
                        Vector2 mousecurrent = Mouse.current.position.ReadValue();

                        if (viewPos.x <= 0)
                        {
                            Vector2 center = new Vector2(Screen.width * 0f, mousecurrent.y);
                            Mouse.current.WarpCursorPosition(center);
                        }
                        if (viewPos.x >= 1)
                        {
                            Vector2 center = new Vector2(Screen.width * 1f, mousecurrent.y);
                            Mouse.current.WarpCursorPosition(center);
                        }

                        anchormouseposition();

                        Vector3 CamaraPos = Camera.main.ScreenToWorldPoint(screenPos);
                        worldPos.y = CamaraPos.y;
                        Vector2 mousePixel = Mouse.current.position.ReadValue();
                        Vector3 ViewPos = Camera.main.ScreenToViewportPoint(mousePixel);
                        slider.value = Mathf.InverseLerp(maxY, minY, saveworldPosy);
                        float mouseX = Mouse.current.position.ReadValue().x;
                        float MouseZ = Mathf.Lerp(-30f, 30f, mouseX / Screen.width); //Screen.width는 현재 디스플레이 크기
                        float smoothZ = Mathf.LerpAngle(Hand.transform.eulerAngles.z, MouseZ, Time.deltaTime * 5); //손 회전
                        Hand.transform.eulerAngles = new Vector3(0, 0, smoothZ);

                        float targettheZ = Hand.transform.eulerAngles.z;
                        targettheZ = Mathf.DeltaAngle(0, targettheZ); //유니티가 강제로 마이너스 각도를 양수로 바꾼걸 다시 원래대로 바꿈
                        float targetZ = Mathf.Clamp(targettheZ, -30f, 30f); //최솟값 밑으로 떨어지거나 최대값을 넘지 못하게 하는 함수
                        Hand.transform.eulerAngles = new Vector3(0f, 0f, targetZ);
                    }
                    else
                    {
                        Hand.transform.eulerAngles = new Vector3(0f, 0f, 0f);
                        worldPos.x = 0f;
                    }
                }

                if (!StopHand)
                {
                    if (HandGrip)
                    {
                        Hand.transform.position = new Vector3(MainCamera.transform.position.x, saveworldPosy + 0.5f, worldPos.z); //클릭 시 자동차가 아래로 내려가는 문제 +0.5f수정
                    }
                    else
                    {
                        Hand.transform.position = new Vector3(MainCamera.transform.position.x, worldPos.y, worldPos.z);
                    }
                }
            }
        }
    }
    private void handpos()
    {
        Vector3 starting = new Vector3(0f, slider.value, 0f); //슬라이더 값에 따라 출발점 변환
        Car.transform.position = Hand.transform.position - starting;
        handposition = true;
    }

    private void anchormouseposition()
    {
        if (!mouseAnchor)
        {
            if (!going)
            {
                worldPos.x = 0f;
                Vector3 targetScreen = Camera.main.WorldToScreenPoint(Vector3.zero);
                Vector2 center = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);
                Mouse.current.WarpCursorPosition(center);
                mouseAnchor = true;
            }
        }
    }
}