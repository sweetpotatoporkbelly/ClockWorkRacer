using UnityEngine;
using System;

public class CarController : MonoBehaviour
{
    public static bool ObstacleCar = false; //차가 막혔을 때 장애물이 쌓이는 상황 방지
    public static event Action bump;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        ObstacleCar = true;

        if (GameManager.speed > 1)
        {
            GameManager.speed -= 1f;
        }
        bump?.Invoke(); //물음표는 신호 받는 스크립트가 있는지 확인하는 것
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        ObstacleCar = false;
    }
}