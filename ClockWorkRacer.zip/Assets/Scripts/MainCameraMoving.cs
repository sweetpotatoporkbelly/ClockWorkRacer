using UnityEngine;
public class MainCameraMoving : MonoBehaviour
{
    float timer = 0f;
    bool endtimer = false;
    [SerializeField] private Transform Car; //위치만 옮길거면 private Transform이 훨씬 편리!!
    void Update()
    {
        if (HandMove.going)
        {
            timer += Time.deltaTime;

            //손 놓으면 카메라를 차에 고정
            if (timer > 0.3 && endtimer == false)
            {
                Vector3 targetPos = new Vector3(Car.position.x, Car.position.y + 2, transform.position.z);
                transform.position = Vector3.Lerp(transform.position, targetPos, Time.deltaTime * 5f);
                endtimer = true;
            }
            else if (endtimer == true)
            {
                Vector3 twotargetPos = new Vector3(Car.position.x, Car.position.y + 2, transform.position.z);
                transform.position = Vector3.Lerp(transform.position, twotargetPos, Time.deltaTime * 5f);
            }
        }
    }
}